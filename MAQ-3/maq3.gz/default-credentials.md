# Default Credentials - MAQ-3 (Linux Debian)

- **root**: toor
- **ftpuser**: password123
- **smbuser**: password123
- **anonymous FTP**: (no password)

> Estas credenciais são intencionalmente fracas para fins de laboratório. 